#!/usr/bin/env python3
"""Standalone CLI wrapper; also works before an editable installation."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from qwen_spline_lab.cli import main

if __name__ == "__main__":
    main(["download", *sys.argv[1:]])
