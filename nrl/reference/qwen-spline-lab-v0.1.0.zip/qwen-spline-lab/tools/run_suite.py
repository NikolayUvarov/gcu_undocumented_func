#!/usr/bin/env python3
"""Run independent conversion/training/evaluation processes from a JSON experiment grid.

Use a VALIDATION text corpus while selecting variants; reserve final test data for
one final evaluation. All paths can be supplied without editing this script.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(ROOT / "configs/suite_single_layer.json"))
    parser.add_argument("--model", required=True)
    parser.add_argument("--calibration", required=True)
    parser.add_argument("--data", required=True, help="Validation documents, NOT final test corpus")
    parser.add_argument("--output", required=True)
    parser.add_argument("--device", default="auto")
    parser.add_argument("--dtype", default="auto")
    parser.add_argument("--threads", type=int, default=4)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--skip-benchmark", action="store_true")
    args = parser.parse_args()
    config = json.loads(Path(args.config).read_text(encoding="utf-8"))
    out = Path(args.output).resolve()
    if out.exists():
        parser.error("Output already exists. Choose a new directory; failed runs keep logs for diagnosis.")
    variants = config["variants"]
    names = [v["name"] for v in variants]
    if not variants or len(set(names)) != len(names) or any(not re.fullmatch(r"[A-Za-z0-9_-]+", n) or n in {"baseline", "comparison", "logs"} for n in names):
        parser.error("Variant names must be unique non-empty safe names using letters, digits, '_' or '-'")
    out.mkdir(parents=True)
    (out / "logs").mkdir()
    (out / "effective_config.json").write_text(json.dumps(config,indent=2),encoding="utf-8")
    env = os.environ.copy()
    env["PYTHONPATH"] = str(ROOT / "src") + os.pathsep + env.get("PYTHONPATH", "")
    common = ["--seed", str(args.seed), "--threads", str(args.threads)]
    runtime = ["--device", args.device, "--dtype", args.dtype]

    def run(name, command):
        print(f"[{name}]", flush=True)
        cmd = [sys.executable, "-m", "qwen_spline_lab", *command, *common]
        logfile = out / "logs" / f"{name}.log"
        with logfile.open("w", encoding="utf-8") as f:
            f.write("COMMAND: " + json.dumps(cmd,ensure_ascii=False) + "\n")
            f.flush()
            result = subprocess.run(cmd, env=env, stdout=f, stderr=subprocess.STDOUT, text=True)
        if result.returncode:
            print("\n".join(logfile.read_text(encoding="utf-8",errors="replace").splitlines()[-30:]),file=sys.stderr)
            raise SystemExit(f"Stage failed: {name}. Log: {logfile}")

    evaluation = config.get("evaluation", {})
    eopts = ["--data", str(Path(args.data).resolve()), "--context", str(evaluation.get("context",256)),
             "--stride", str(evaluation.get("stride",128)), "--max-tokens", str(evaluation.get("max_tokens",4096))]
    benchmark = config.get("benchmark", {})
    bopts = ["--context", str(benchmark.get("context",128)), "--decode-steps",str(benchmark.get("decode_steps",32)),
             "--repeats",str(benchmark.get("repeats",5)),"--warmup",str(benchmark.get("warmup",2))]
    baseline = out / "baseline.eval.json"
    run("baseline_evaluate",["evaluate","--model",args.model,*runtime,*eopts,"--output",str(baseline)])
    benches, results = [], []
    if not args.skip_benchmark:
        path = out / "baseline.benchmark.json"
        run("baseline_benchmark",["benchmark","--model",args.model,*runtime,*bopts,"--output",str(path)])
        benches.append(str(path))
    train = config.get("training", {})
    for variant in variants:
        name = variant["name"]
        initial, trained = out / f"{name}.initial", out / f"{name}.trained"
        cmd = ["convert","--model",args.model,"--calibration",args.calibration,
               "--layers",config.get("layers","14"),"--representation",variant["representation"],
               "--width",str(variant.get("width",1024)),"--rank",str(variant.get("rank",256)),
               "--knots",str(variant.get("knots",16)),"--output",str(initial),*runtime]
        run(name+"_convert",cmd)
        final = initial
        if variant["representation"] != "dense" and train.get("steps",500)>0:
            run(name+"_train",["train","--artifact",str(initial),"--calibration",args.calibration,
                              "--output",str(trained),"--device",args.device,
                              "--steps",str(train.get("steps",500)),"--lr",str(train.get("lr",0.001)),
                              "--batch-size",str(train.get("batch_size",256)),
                              "--eval-every",str(train.get("eval_every",50))])
            final = trained
        run(name+"_block_validation",["block-test","--artifact",str(final),"--calibration",args.calibration,
                                      "--split","validation","--device",args.device,
                                      "--output",str(out/f"{name}.blocks.json")])
        path = out / f"{name}.eval.json"
        run(name+"_evaluate",["evaluate","--model",str(final),*runtime,*eopts,"--output",str(path)])
        results.append(str(path))
        if not args.skip_benchmark:
            path = out / f"{name}.benchmark.json"
            run(name+"_benchmark",["benchmark","--model",str(final),*runtime,*bopts,"--output",str(path)])
            benches.append(str(path))
    cmd = ["compare","--baseline",str(baseline),"--results",*results,
           "--output",str(out/"comparison"),"--max-ppl-ratio",str(config.get("max_ppl_ratio",1.05))]
    if benches:
        cmd.extend(["--benchmarks",*benches])
    run("comparison",cmd)
    print(f"Results: {out / 'comparison.md'}")


if __name__ == "__main__":
    main()
