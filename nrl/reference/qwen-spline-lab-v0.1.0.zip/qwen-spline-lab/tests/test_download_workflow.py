"""Test download pin/resume logic with a stub Hub; never access the network."""
import sys
from types import SimpleNamespace

import pytest
import torch
from safetensors.torch import save_file

from qwen_spline_lab.hf import download_model
from qwen_spline_lab.utils import read_json, write_json


def test_download_pins_commit_and_resumes_without_resolving_main_again(tmp_path,monkeypatch):
    calls=[]
    class Api:
        def model_info(self,repo_id,revision):
            calls.append((repo_id,revision))
            return SimpleNamespace(sha="fixed-commit")
    def snapshot_download(**kwargs):
        from pathlib import Path
        root=Path(kwargs["local_dir"])
        assert kwargs["revision"]=="fixed-commit"
        assert "*.py" in kwargs["ignore_patterns"]
        write_json(root/"config.json",{"model_type":"qwen3"})
        save_file({"example":torch.ones(2)},str(root/"model.safetensors"))
    monkeypatch.setitem(sys.modules,"huggingface_hub",SimpleNamespace(HfApi=Api,snapshot_download=snapshot_download))
    out=tmp_path/"download"
    first=download_model("Qwen/example",str(out))
    second=download_model("Qwen/example",str(out))
    assert first==second
    assert calls==[("Qwen/example","main")]
    assert read_json(out/"download_lock.json")["commit"]=="fixed-commit"
    with pytest.raises(ValueError,match="different repository"):
        download_model("Qwen/other",str(out))


def test_download_does_not_mix_existing_untracked_directory(tmp_path,monkeypatch):
    monkeypatch.setitem(sys.modules,"huggingface_hub",SimpleNamespace(HfApi=object,snapshot_download=lambda **kw:None))
    (tmp_path/"existing.txt").write_text("keep")
    with pytest.raises(ValueError,match="not empty"):
        download_model("Qwen/example",str(tmp_path))
    assert (tmp_path/"existing.txt").read_text()=="keep"


def test_adapter_rejects_noncausal_or_quantized_qwen():
    from qwen_spline_lab.hf import validate_qwen
    with pytest.raises(ValueError,match="embedding/reranking"):
        validate_qwen(SimpleNamespace(model_type="qwen3",hidden_act="silu",architectures=["Qwen3Model"]))
    with pytest.raises(ValueError,match="pre-quantized"):
        validate_qwen(SimpleNamespace(model_type="qwen3",hidden_act="silu",architectures=["Qwen3ForCausalLM"],
                                     quantization_config={"quant_method":"gptq"}))
