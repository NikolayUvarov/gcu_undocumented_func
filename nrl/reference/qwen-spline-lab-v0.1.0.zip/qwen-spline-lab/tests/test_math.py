import pytest
import torch
from torch.func import functional_call

from qwen_spline_lab.representations import (
    BlockSpec, ChannelSpline, CompactGatedMLP, LowRankLinear, build_block,
    initialize_block, refit_down,
)
from qwen_spline_lab.training import block_metrics, train_block
from qwen_spline_lab.utils import parameter_stats


@pytest.mark.parametrize("kind", ["linear", "cubic"])
@pytest.mark.parametrize("knots", [2, 4, 16])
def test_spline_reproduces_affine_function_and_linear_tails(kind, knots):
    spline = ChannelSpline(3, knots, kind).double()
    slopes = torch.tensor([0.5, -2.0, 3.0], dtype=torch.float64)
    offsets = torch.tensor([1.0, 2.0, -0.5], dtype=torch.float64)
    grid = torch.linspace(-6, 6, knots, dtype=torch.float64)
    with torch.no_grad():
        spline.values.copy_(slopes[:, None] * grid + offsets[:, None])
    x = torch.tensor([[-100, -4.35, 0.1], [1.2, 6, 100]], dtype=torch.float64, requires_grad=True)
    actual = spline(x)
    torch.testing.assert_close(actual, x * slopes + offsets, atol=1e-10, rtol=1e-10)
    actual.sum().backward()
    torch.testing.assert_close(x.grad, slopes.expand_as(x), atol=1e-10, rtol=1e-10)


@pytest.mark.parametrize("kind", ["linear", "cubic"])
def test_spline_gradcheck_input_and_coefficients(kind):
    spline = ChannelSpline(2, 7, kind).double()
    x = torch.tensor([[-5.1, -1.3], [2.4, 7.7]], dtype=torch.float64, requires_grad=True)
    values = spline.values.detach().clone().requires_grad_(True)
    assert torch.autograd.gradcheck(lambda a, b: functional_call(spline, {"values": b}, (a,)),
                                   (x, values), eps=1e-6, atol=1e-5, rtol=1e-4)


@pytest.mark.parametrize("kind", ["linear", "cubic"])
def test_spline_interpolates_knots(kind):
    spline = ChannelSpline(2, 9, kind)
    x = torch.linspace(-6, 6, 9)[:, None].expand(-1, 2)
    torch.testing.assert_close(spline(x), spline.values.T)


def test_grid_fitted_on_supplied_samples():
    spline = ChannelSpline(2, 8)
    x = torch.randn(500, 2) * torch.tensor([0.5, 4.0])
    spline.initialize_silu(x)
    assert (spline.high > spline.low).all()
    assert spline.high[1] - spline.low[1] > spline.high[0] - spline.low[0]
    assert (spline.low <= -0.1).all() and (spline.high >= 0.1).all()


@pytest.mark.parametrize("kind", ["linear", "cubic"])
def test_spline_bfloat16_is_finite(kind):
    spline = ChannelSpline(3, 16, kind)
    x = torch.randn(2, 5, 3)
    result = spline(x.bfloat16())
    assert result.dtype == torch.bfloat16 and torch.isfinite(result).all()
    torch.testing.assert_close(result.float(), spline(x).float(), atol=0.02, rtol=0.02)


def test_dense_conversion_is_identity():
    teacher = CompactGatedMLP(BlockSpec("dense", 8, 16, width=16))
    student = initialize_block(teacher, teacher.spec)
    x = torch.randn(19, 8)
    torch.testing.assert_close(student(x), teacher(x), atol=0, rtol=0)


def test_pruned_and_spline_use_same_channels():
    teacher = CompactGatedMLP(BlockSpec("dense", 8, 16, width=16))
    x = torch.randn(100, 8)
    pruned = initialize_block(teacher, BlockSpec("pruned", 8, 16, width=6), x)
    spline = initialize_block(teacher, BlockSpec("spline-linear", 8, 16, width=6), x)
    torch.testing.assert_close(pruned.gate_proj.weight, spline.gate_proj.weight, atol=0, rtol=0)
    torch.testing.assert_close(pruned.up_proj.weight, spline.up_proj.weight, atol=0, rtol=0)
    torch.testing.assert_close(pruned.down_proj.weight, spline.down_proj.weight, atol=0, rtol=0)


@pytest.mark.parametrize("method", ["exact", "randomized"])
def test_full_rank_svd_reconstructs_weight(method):
    weight = torch.randn(7, 5)
    layer = LowRankLinear(5, 7, 5)
    layer.initialize(weight, method)
    torch.testing.assert_close(layer.left.weight @ layer.right.weight, weight, atol=1e-5, rtol=1e-5)


def test_parameter_formulas():
    h, m, r, k = 24, 64, 12, 16
    assert parameter_stats(build_block(BlockSpec("dense", h, m, width=m)))["parameters"] == 3*h*m
    assert parameter_stats(build_block(BlockSpec("pruned", h, m, width=r)))["parameters"] == 3*h*r
    assert parameter_stats(build_block(BlockSpec("spline-linear", h, m, width=r, knots=k)))["parameters"] == 3*h*r+r*k
    assert parameter_stats(build_block(BlockSpec("svd", h, m, rank=r)))["parameters"] == 3*r*(h+m)


def test_ridge_refit_improves_training_error():
    teacher = CompactGatedMLP(BlockSpec("dense", 8, 24, width=24))
    x = torch.randn(256, 8)
    y = teacher(x).detach()
    student = initialize_block(teacher, BlockSpec("pruned", 8, 24, width=8), x)
    before = block_metrics(student, x, y)["nmse"]
    refit_down(student, x, y)
    after = block_metrics(student, x, y)["nmse"]
    assert after < before


def test_training_selects_checkpoint_using_validation_only():
    teacher = CompactGatedMLP(BlockSpec("dense", 6, 12, width=12))
    x, xv = torch.randn(256, 6), torch.randn(128, 6)
    y, yv = teacher(x).detach(), teacher(xv).detach()
    block = initialize_block(teacher, BlockSpec("spline-linear", 6, 12, width=6), x)
    result = train_block(block, (x, y), (xv, yv), steps=30, batch_size=64, eval_every=5)
    assert result["selection_split"] == "validation"
    assert result["final_validation"]["nmse"] <= result["initial_validation"]["nmse"] + 1e-10
    assert result["best_step"] in [0, 5, 10, 15, 20, 25, 30]


@pytest.mark.parametrize("kwargs", [dict(width=0), dict(width=17), dict(knots=1)])
def test_invalid_spec_rejected(kwargs):
    fields = dict(representation="spline-linear", hidden_size=8, original_width=16, width=8, knots=16)
    fields.update(kwargs)
    with pytest.raises(ValueError):
        BlockSpec(**fields)
