import json

import pytest
import torch

from qwen_spline_lab.artifacts import load_overlay, save_overlay, verify_calibration
from qwen_spline_lab.data import (check_disjoint, document_hash, evaluation_windows, load_pairs,
                                  read_documents, save_pairs, split_corpus)
from qwen_spline_lab.representations import REPRESENTATIONS, BlockSpec, build_block
from qwen_spline_lab.utils import (model_fingerprint, new_directory, parameter_stats, parse_layers,
                                  sha256_file, write_json)


@pytest.mark.parametrize("representation", REPRESENTATIONS)
def test_artifact_roundtrip_and_checksum(tmp_path, representation):
    spec = BlockSpec(representation, 8, 16, width=16 if representation == "dense" else 5, rank=3)
    block = build_block(spec)
    path = tmp_path / "artifact"
    base = {"source": "/tmp/example", "fingerprint": "abc"}
    manifest = save_overlay(path, {2: block}, base)
    blocks, loaded = load_overlay(path)
    assert loaded["artifact_id"] == manifest["artifact_id"]
    x = torch.randn(10, 8)
    torch.testing.assert_close(block(x), blocks[2](x), atol=0, rtol=0)
    with pytest.raises(FileExistsError):
        save_overlay(path, {2: block}, base)
    with (path / "blocks.safetensors").open("ab") as f:
        f.write(b"bad")
    with pytest.raises(ValueError, match="checksum"):
        load_overlay(path)


def test_atomic_output_cleanup(tmp_path):
    out = tmp_path / "new"
    with pytest.raises(RuntimeError):
        with new_directory(out) as temp:
            (temp / "partial.txt").write_text("partial")
            raise RuntimeError("interrupted")
    assert not out.exists() and list(tmp_path.iterdir()) == []


def test_data_split_no_overlap_and_no_duplicate_leak(tmp_path):
    docs = [f"Документ {i}. Test content." for i in range(20)] + ["Документ   0. Test content."]
    source = tmp_path / "source.jsonl"
    source.write_text("\n".join(json.dumps({"text": d}, ensure_ascii=False) for d in docs), encoding="utf-8")
    result = split_corpus(str(source), str(tmp_path / "splits"))
    assert result["input_documents"] == 21 and result["unique_documents"] == 20
    parsed = {s: read_documents(tmp_path / "splits" / f"{s}.jsonl") for s in ["train", "validation", "test"]}
    check_disjoint(parsed)
    assert sum(map(len, parsed.values())) == 20
    with pytest.raises(ValueError, match="leakage"):
        check_disjoint({"train": ["a b"], "test": ["a   b"]})


@pytest.mark.parametrize("length,context,stride", [(2,2,1),(17,8,4),(33,9,8),(40,16,1),(7,512,256)])
def test_perplexity_windows_score_every_target_once(length, context, stride):
    ids = list(range(length))
    targets = []
    for window, start, count in evaluation_windows(ids, context, stride):
        assert len(window) <= context
        assert 0 <= start < len(window)-1
        targets.extend(window[start+1:start+count+1])
    assert targets == ids[1:]


def test_evaluation_windows_respect_global_budget():
    result = list(evaluation_windows(list(range(100)), 16, 8, max_targets=19))
    targets = [i for w, s, n in result for i in w[s+1:s+n+1]]
    assert targets == list(range(1,20))


def test_calibration_checksums_and_base_identity(tmp_path):
    name = "layer_000.train.safetensors"
    x, y = torch.randn(20,8), torch.randn(20,8)
    save_pairs(tmp_path/name, x, y, torch.float32)
    write_json(tmp_path/"calibration.json", {"files": {name: sha256_file(tmp_path/name)}})
    xx, yy = load_pairs(tmp_path, 0, "train")
    torch.testing.assert_close(x, xx, atol=0, rtol=0)
    torch.testing.assert_close(y, yy, atol=0, rtol=0)
    with pytest.raises(ValueError, match="different base"):
        verify_calibration({"base":{"fingerprint":"A"}}, {"base":{"fingerprint":"B"},"layers":[0]}, [0])


def test_fingerprint_changes_with_weight_bytes(tmp_path):
    (tmp_path/"config.json").write_text('{"model_type":"qwen3"}')
    (tmp_path/"model.safetensors").write_bytes(b"first")
    first = model_fingerprint(tmp_path)
    (tmp_path/"model.safetensors").write_bytes(b"second")
    assert model_fingerprint(tmp_path) != first


def test_layer_parser_and_tied_parameter_count():
    assert parse_layers("3,1,3", 5) == [1,3]
    assert parse_layers("all", 3) == [0,1,2]
    with pytest.raises(ValueError): parse_layers("5",5)
    m = torch.nn.Module()
    m.a = torch.nn.Linear(4,4,bias=False)
    m.b = torch.nn.Linear(4,4,bias=False)
    m.b.weight = m.a.weight
    assert parameter_stats(m)["parameters"] == 16
