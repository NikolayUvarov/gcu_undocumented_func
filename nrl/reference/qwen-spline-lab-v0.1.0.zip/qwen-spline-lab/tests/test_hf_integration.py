"""Small randomly initialized Qwen3. No network or pretrained weights are used.

Run after pip install -e '.[hf,dev]'. This module is skipped if Transformers is absent.
These integration tests do NOT establish quality on trained Qwen3-0.6B weights.
"""
import json

import pytest
import torch

transformers = pytest.importorskip("transformers", reason="Optional HF adapter is not installed")
pytestmark = pytest.mark.integration

from qwen_spline_lab.artifacts import load_overlay, save_overlay
from qwen_spline_lab.hf import apply_blocks, capture_pairs, export_standalone, load_any
from qwen_spline_lab.representations import BlockSpec, initialize_block


@pytest.fixture
def tiny_qwen(tmp_path):
    from tokenizers import Tokenizer, models, pre_tokenizers
    from transformers import PreTrainedTokenizerFast, Qwen3Config, Qwen3ForCausalLM
    config=Qwen3Config(vocab_size=64,hidden_size=16,intermediate_size=32,num_hidden_layers=2,
                       num_attention_heads=4,num_key_value_heads=2,head_dim=4,max_position_embeddings=128,
                       bos_token_id=1,eos_token_id=2,pad_token_id=0,tie_word_embeddings=True)
    config._attn_implementation="eager"
    model=Qwen3ForCausalLM(config).eval()
    folder=tmp_path/"base"
    model.save_pretrained(folder,safe_serialization=True)
    vocab={"[PAD]":0,"[BOS]":1,"[EOS]":2,"[UNK]":3, **{f"t{i}":i for i in range(4,64)}}
    backend=Tokenizer(models.WordLevel(vocab,unk_token="[UNK]"))
    backend.pre_tokenizer=pre_tokenizers.Whitespace()
    tokenizer=PreTrainedTokenizerFast(tokenizer_object=backend,unk_token="[UNK]",pad_token="[PAD]",
                                     bos_token="[BOS]",eos_token="[EOS]")
    tokenizer.save_pretrained(folder)
    return folder


@pytest.mark.parametrize("representation",["dense","pruned","spline-linear","spline-cubic","svd"])
def test_real_qwen_graph_patch_and_standalone(tmp_path,tiny_qwen,representation):
    model,tok,info=load_any(tiny_qwen,torch.device("cpu"),torch.float32,attention="eager")
    pairs,_=capture_pairs(model,tok,["t4 t5 t6 t7 t8 t9"],[0],max_tokens=6,context_length=8)
    spec=BlockSpec(representation,16,32,width=32 if representation=="dense" else 12,rank=4)
    block=initialize_block(model.model.layers[0].mlp,spec,pairs[0][0],svd_method="exact")
    overlay=tmp_path/"overlay"
    manifest=save_overlay(overlay,{0:block},info["base"])
    modified,mt,mi=load_any(overlay,torch.device("cpu"),torch.float32,attention="eager")
    ids=torch.tensor([[4,5,6,7]])
    with torch.no_grad(): expected=modified(input_ids=ids).logits
    if representation=="dense":
        with torch.no_grad(): torch.testing.assert_close(expected,model(input_ids=ids).logits,atol=0,rtol=0)
    standalone=tmp_path/"standalone"
    export_standalone(modified,mt,mi,manifest,str(standalone))
    tiny_qwen.rename(tmp_path/"base_moved_away")
    loaded,_,_=load_any(standalone,torch.device("cpu"),torch.float32,attention="eager")
    with torch.no_grad(): actual=loaded(input_ids=ids).logits
    torch.testing.assert_close(actual,expected,atol=0,rtol=0)
    assert loaded.lm_head.weight.data_ptr()==loaded.model.embed_tokens.weight.data_ptr()
    result=loaded.generate(ids,max_new_tokens=3,do_sample=False,pad_token_id=0)
    assert result.shape[1]>=4
