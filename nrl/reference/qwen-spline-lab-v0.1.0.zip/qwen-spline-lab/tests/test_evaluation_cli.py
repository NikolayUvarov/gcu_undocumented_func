import copy
import json
import math
from types import SimpleNamespace

import pytest
import torch
from torch import nn

from qwen_spline_lab.cli import main, parser_factory
from qwen_spline_lab.evaluation import benchmark_model, compare_reports, evaluate_language_model
from qwen_spline_lab.utils import write_json


class IntegerTokenizer:
    def __call__(self, text, **kwargs):
        return {"input_ids": [int(x) for x in text.split()]}


class UniformBackbone(nn.Module):
    def forward(self, input_ids, **kwargs):
        return SimpleNamespace(last_hidden_state=torch.zeros(*input_ids.shape,4,device=input_ids.device))


class UniformModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.model = UniformBackbone()
        self.lm_head = nn.Linear(4,7,bias=False)
        nn.init.zeros_(self.lm_head.weight)
        self.config = SimpleNamespace(max_position_embeddings=256)
        self.calls = []

    def forward(self, input_ids, past_key_values=None, **kwargs):
        self.calls.append((input_ids.shape[1], past_key_values))
        return SimpleNamespace(logits=torch.zeros(1,1,7),
                               past_key_values=(past_key_values or 0)+input_ids.shape[1])


def info(model_id="base"):
    return {"path": f"/test/{model_id}", "model_id": model_id, "dtype":"float32", "device":"cpu",
            "attention":"eager", "parameters":28,"parameter_bytes":112,
            "base":{"fingerprint":"fixed"}}


def test_perplexity_uniform_model_and_token_count(tmp_path):
    data = tmp_path/"test.jsonl"
    data.write_text('\n'.join(json.dumps({"text":s}) for s in ["1 2 3 4 5 6", "2 1 3"]))
    report = evaluate_language_model(UniformModel(), IntegerTokenizer(), info(), str(data),
                                     context=4, stride=2,max_tokens=100,head_chunk=1)
    assert report["protocol"]["scored_tokens"] == 7
    assert report["perplexity"] == pytest.approx(7,rel=1e-6)
    assert report["nll_nats_per_token"] == pytest.approx(math.log(7),rel=1e-6)
    limited = evaluate_language_model(UniformModel(),IntegerTokenizer(),info(),str(data),
                                      context=4,stride=2,max_tokens=6)
    assert limited["protocol"]["scored_tokens"] == 6


def test_cached_benchmark_has_fixed_work_and_resets_cache():
    model=UniformModel()
    report=benchmark_model(model,IntegerTokenizer(),info(),prompt="1 2 3",context=5,
                           decode_steps=3,repeats=2,warmup=1)
    assert len(model.calls) == 12
    assert [model.calls[i] for i in [0,4,8]] == [(5,None)]*3
    assert model.calls[1:4] == [(1,5),(1,6),(1,7)]
    assert report["cached_decode_tokens_per_second"]["median"]>0
    assert len(report["prefill_ms"]["runs"])==2


def test_comparison_rejects_mismatched_protocols(tmp_path):
    baseline={"report_type":"language_model_evaluation","model":info(),"protocol":{"tokens":10},"perplexity":10.0}
    altered=copy.deepcopy(baseline)
    altered["model"]=info("compressed")
    altered["model"]["parameters"]=14
    altered["perplexity"]=10.3
    write_json(tmp_path/"base.json",baseline)
    write_json(tmp_path/"result.json",altered)
    result=compare_reports(str(tmp_path/"base.json"),[str(tmp_path/"result.json")],[],str(tmp_path/"compare"))
    assert result["rows"][1]["parameter_ratio"]==0.5
    assert result["rows"][1]["quality_gate_passed"]
    assert (tmp_path/"compare.csv").is_file() and (tmp_path/"compare.md").is_file()
    altered["protocol"]["tokens"]=11
    write_json(tmp_path/"result.json",altered)
    with pytest.raises(ValueError,match="Incomparable"):
        compare_reports(str(tmp_path/"base.json"),[str(tmp_path/"result.json")],[],str(tmp_path/"bad"))


@pytest.mark.parametrize("command",["download","split","calibrate","convert","train","block-test","evaluate",
                                    "benchmark","generate","export","compare","doctor","demo"])
def test_each_separate_tool_has_help(command,capsys):
    with pytest.raises(SystemExit) as e: main([command,"--help"])
    assert e.value.code==0
    assert "usage:" in capsys.readouterr().out


def test_cli_representation_choices():
    p=parser_factory()
    args=p.parse_args(["convert","--model","m","--output","o","--representation","spline-cubic"])
    assert args.representation=="spline-cubic" and args.refit
    with pytest.raises(SystemExit):
        p.parse_args(["convert","--model","m","--output","o","--representation","magic-kan"])
