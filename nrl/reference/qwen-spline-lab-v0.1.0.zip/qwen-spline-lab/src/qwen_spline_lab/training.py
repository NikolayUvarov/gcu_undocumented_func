from __future__ import annotations

import logging
import math

import torch
from torch import nn
from torch.nn import functional as F

from .representations import ChannelSpline

log = logging.getLogger(__name__)


@torch.inference_mode()
def block_metrics(block: nn.Module, x: torch.Tensor, y: torch.Tensor, batch_size: int = 256) -> dict:
    if len(x) != len(y) or len(x) == 0 or batch_size < 1:
        raise ValueError("Invalid evaluation inputs")
    block.eval()
    parameter = next(block.parameters())
    squared_error = target_energy = cosine_sum = 0.0
    outside = gate_count = 0
    for start in range(0, len(x), batch_size):
        xb = x[start:start + batch_size].to(parameter)
        yb = y[start:start + batch_size].to(parameter).float()
        pred = block(xb).float()
        if not torch.isfinite(pred).all():
            raise FloatingPointError("Block produced non-finite outputs")
        squared_error += (pred - yb).double().square().sum().item()
        target_energy += yb.double().square().sum().item()
        cosine_sum += F.cosine_similarity(pred, yb, dim=-1).double().sum().item()
        activation = getattr(block, "activation", None)
        if isinstance(activation, ChannelSpline):
            gate = block.gate_proj(xb).float()
            outside += ((gate < activation.low) | (gate > activation.high)).sum().item()
            gate_count += gate.numel()
    return {"tokens": len(x), "nmse": squared_error / max(target_energy, 1e-30),
            "mse": squared_error / y.numel(), "mean_cosine": cosine_sum / len(x),
            "outside_grid_fraction": outside / gate_count if gate_count else None}


def train_block(block: nn.Module, train: tuple[torch.Tensor, torch.Tensor],
                validation: tuple[torch.Tensor, torch.Tensor], *, steps: int = 500,
                batch_size: int = 256, lr: float = 1e-3, eval_every: int = 50,
                seed: int = 42, smoothness: float = 0.0) -> dict:
    if steps < 0 or batch_size < 1 or lr <= 0 or eval_every < 1 or smoothness < 0:
        raise ValueError("Invalid training hyperparameters")
    x, y = train
    if x.ndim != 2 or x.shape != y.shape or not len(x):
        raise ValueError("Invalid training pairs")
    block.float()
    for p in block.parameters():
        p.requires_grad_(True)
    parameter = next(block.parameters())
    generator = torch.Generator(device="cpu").manual_seed(seed)
    optimizer = torch.optim.AdamW(block.parameters(), lr=lr, weight_decay=0.0)
    target_energy = max(y.double().square().mean().item(), 1e-20)
    initial = block_metrics(block, *validation, batch_size=batch_size)
    best_score, best_step = initial["nmse"], 0
    best_state = {k: v.detach().cpu().clone() for k, v in block.state_dict().items()}
    history = [{"step": 0, "validation_nmse": best_score}]
    for step in range(1, steps + 1):
        block.train()
        indices = torch.randint(len(x), (min(batch_size, len(x)),), generator=generator)
        xb, yb = x[indices].to(parameter), y[indices].to(parameter)
        optimizer.zero_grad(set_to_none=True)
        pred = block(xb)
        loss = (pred - yb).square().mean() / target_energy
        activation = getattr(block, "activation", None)
        if smoothness and isinstance(activation, ChannelSpline):
            loss = loss + smoothness * activation.roughness()
        if not torch.isfinite(loss):
            raise FloatingPointError("Non-finite training loss. Lower learning rate or inspect calibration.")
        loss.backward()
        norm = torch.nn.utils.clip_grad_norm_(block.parameters(), 1.0, error_if_nonfinite=True)
        optimizer.step()
        if step % eval_every == 0 or step == steps:
            metrics = block_metrics(block, *validation, batch_size=batch_size)
            value = metrics["nmse"]
            history.append({"step": step, "train_loss": loss.item(), "gradient_norm": float(norm),
                            "validation_nmse": value})
            if value < best_score:
                best_score, best_step = value, step
                best_state = {k: v.detach().cpu().clone() for k, v in block.state_dict().items()}
            log.info("step %d/%d validation NMSE %.6g; best %.6g", step, steps, value, best_score)
    block.load_state_dict(best_state, strict=True)
    block.eval()
    final = block_metrics(block, *validation, batch_size=batch_size)
    if not math.isfinite(final["nmse"]):
        raise FloatingPointError("Non-finite final validation error")
    return {"selection_split": "validation", "initial_validation": initial, "final_validation": final,
            "best_step": best_step, "steps": steps, "batch_size": batch_size, "lr": lr,
            "seed": seed, "smoothness": smoothness, "history": history}
