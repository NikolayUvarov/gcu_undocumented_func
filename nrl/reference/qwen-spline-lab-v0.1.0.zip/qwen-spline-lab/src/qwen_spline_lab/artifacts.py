from __future__ import annotations

import copy
from pathlib import Path

import torch
from safetensors.torch import load_model, save_model
from torch import nn

from .representations import BlockSpec, build_block
from .utils import digest, environment, new_directory, read_json, sha256_file, write_json

OVERLAY_FORMAT = "qwen-spline-lab-overlay-v1"
STANDALONE_FORMAT = "qwen-spline-lab-standalone-v1"


def layer_key(index: int) -> str:
    return f"layer_{index:03d}"


def save_overlay(output: str | Path, blocks: dict[int, nn.Module], base: dict,
                 details: dict | None = None) -> dict:
    if not blocks:
        raise ValueError("No blocks to save")
    # Store patch tensors in float32; loading for inference casts them to the requested model dtype.
    # Keep the caller's modules unchanged.
    bundle = nn.ModuleDict({layer_key(k): copy.deepcopy(v).cpu().float() for k, v in blocks.items()})
    specs = {str(k): v.spec.to_dict() for k, v in sorted(blocks.items())}
    with new_directory(output) as tmp:
        weights = tmp / "blocks.safetensors"
        save_model(bundle, str(weights), metadata={"format": "pt"})
        manifest = {"format": OVERLAY_FORMAT, "base": base, "blocks": specs,
                    "weights_sha256": sha256_file(weights), "patch_file_bytes": weights.stat().st_size,
                    "patch_storage_dtype": "float32", "environment": environment(), "details": details or {}}
        manifest["artifact_id"] = digest({"base": base["fingerprint"], "blocks": specs,
                                           "weights": manifest["weights_sha256"]})
        write_json(tmp / "manifest.json", manifest)
    return manifest


def load_overlay(path: str | Path) -> tuple[dict[int, nn.Module], dict]:
    path = Path(path)
    manifest = read_json(path / "manifest.json")
    if manifest.get("format") != OVERLAY_FORMAT:
        raise ValueError("Expected an overlay artifact")
    weights = path / "blocks.safetensors"
    if sha256_file(weights) != manifest["weights_sha256"]:
        raise ValueError("Patch checksum mismatch: artifact is corrupted or was modified")
    blocks = {int(k): build_block(BlockSpec(**v)) for k, v in manifest["blocks"].items()}
    bundle = nn.ModuleDict({layer_key(k): v for k, v in blocks.items()})
    load_model(bundle, str(weights), strict=True)
    for block in blocks.values():
        block.eval()
    return blocks, manifest


def verify_calibration(manifest: dict, calibration: dict, layers: list[int]) -> None:
    if manifest["base"]["fingerprint"] != calibration["base"]["fingerprint"]:
        raise ValueError("Calibration and artifact belong to different base weights/tokenizers")
    if not set(layers).issubset(set(calibration["layers"])):
        raise ValueError("Calibration is missing requested layers")
