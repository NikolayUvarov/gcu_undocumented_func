from __future__ import annotations

import csv
import hashlib
import json
import math
import statistics
import time
from pathlib import Path

import torch
from torch.nn import functional as F

from .data import corpus_digest, evaluation_windows, read_documents
from .utils import environment, read_json, sync, write_json


@torch.inference_mode()
def evaluate_language_model(model, tokenizer, info: dict, data: str, *, context: int = 256,
                            stride: int = 128, max_tokens: int = 4096, head_chunk: int = 64) -> dict:
    if max_tokens < 1 or head_chunk < 1:
        raise ValueError("Token budget and head chunk must be positive")
    if context > model.config.max_position_embeddings:
        raise ValueError("Requested context exceeds model configuration")
    if context < 2 or not 1 <= stride < context:
        raise ValueError("Need context >= 2 and 1 <= stride < context")
    docs = read_documents(data)
    total_nll, tokens, windows, used_docs = 0.0, 0, 0, 0
    token_digest = hashlib.sha256()
    device = next(model.parameters()).device
    model.eval()
    for text in docs:
        ids = tokenizer(text, add_special_tokens=False)["input_ids"]
        if len(ids) < 2:
            continue
        used_docs += 1
        for window, start, count in evaluation_windows(ids, context, stride, max_tokens - tokens):
            token_digest.update(json.dumps([window, start, count], separators=(",", ":")).encode())
            input_ids = torch.tensor([window], dtype=torch.long, device=device)
            hidden = model.model(input_ids=input_ids, use_cache=False, return_dict=True).last_hidden_state
            # Do not allocate full context x vocabulary logits. Score only needed positions in chunks.
            for offset in range(start, start + count, head_chunk):
                end = min(offset + head_chunk, start + count)
                logits = model.lm_head(hidden[:, offset:end]).float().reshape(end - offset, -1)
                targets = input_ids[:, offset + 1:end + 1].reshape(-1)
                nll = F.cross_entropy(logits, targets, reduction="sum")
                if not torch.isfinite(nll):
                    raise FloatingPointError("Non-finite language-model loss")
                total_nll += nll.item()
            tokens += count
            windows += 1
        if tokens >= max_tokens:
            break
    if tokens == 0:
        raise ValueError("No scoreable tokens in evaluation corpus")
    nll = total_nll / tokens
    ppl = math.exp(nll) if nll < 700 else None
    return {"report_type": "language_model_evaluation", "model": info, "environment": environment(),
            "protocol": {"corpus_digest": corpus_digest(docs), "context": context, "stride": stride,
                         "max_tokens": max_tokens, "scored_tokens": tokens, "token_digest": token_digest.hexdigest(),
                         "special_tokens": False, "cross_document_windows": False},
            "documents_available": len(docs), "documents_used": used_docs, "windows": windows,
            "nll_nats_per_token": nll, "perplexity": ppl,
            "perplexity_overflow": ppl is None}


def _summary(values: list[float]) -> dict:
    ordered = sorted(values)
    return {"median": statistics.median(ordered), "minimum": ordered[0], "maximum": ordered[-1],
            "runs": values}


@torch.inference_mode()
def benchmark_model(model, tokenizer, info: dict, *, prompt: str, context: int = 128,
                    decode_steps: int = 32, repeats: int = 5, warmup: int = 2,
                    compile_mlp: bool = False) -> dict:
    if min(context, decode_steps, repeats, warmup) < 1:
        raise ValueError("Context, decode steps, repeats and warmup must all be positive")
    if context + decode_steps > model.config.max_position_embeddings:
        raise ValueError("Prompt plus decode exceeds maximum context")
    device = next(model.parameters()).device
    tokens = tokenizer(prompt, add_special_tokens=False)["input_ids"]
    if not tokens:
        raise ValueError("Prompt is empty after tokenization")
    tokens = (tokens * ((context + len(tokens) - 1) // len(tokens)))[:context]
    ids = torch.tensor([tokens], dtype=torch.long, device=device)
    if compile_mlp:
        for layer in model.model.layers:
            layer.mlp = torch.compile(layer.mlp, dynamic=True)
    model.eval()

    def trial():
        sync(device)
        start = time.perf_counter()
        output = model(input_ids=ids, use_cache=True, return_dict=True, logits_to_keep=1)
        sync(device)
        prefill_seconds = time.perf_counter() - start
        token = output.logits[:, -1].argmax(-1, keepdim=True)
        cache = output.past_key_values
        del output
        sync(device)
        start = time.perf_counter()
        # Fixed work, ignoring EOS: speed must not depend on which tokens a model generates.
        for _ in range(decode_steps):
            output = model(input_ids=token, past_key_values=cache, use_cache=True,
                           return_dict=True, logits_to_keep=1)
            token = output.logits[:, -1].argmax(-1, keepdim=True)
            cache = output.past_key_values
        sync(device)
        decode_seconds = time.perf_counter() - start
        del output, cache
        return prefill_seconds * 1000, decode_steps / decode_seconds

    for _ in range(warmup):
        trial()
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(device)
    runs = [trial() for _ in range(repeats)]
    memory = {"cuda_peak_allocated_bytes": None, "cuda_peak_reserved_bytes": None}
    if device.type == "cuda":
        memory = {"cuda_peak_allocated_bytes": torch.cuda.max_memory_allocated(device),
                  "cuda_peak_reserved_bytes": torch.cuda.max_memory_reserved(device)}
    return {"report_type": "benchmark", "model": info, "environment": environment(),
            "protocol": {"context": context, "decode_steps": decode_steps, "batch_size": 1,
                         "token_digest": hashlib.sha256(json.dumps(tokens).encode()).hexdigest(),
                         "repeats": repeats, "warmup": warmup, "compile_mlp": compile_mlp,
                         "dtype": info["dtype"], "device": info["device"], "attention": info["attention"]},
            "prefill_ms": _summary([x[0] for x in runs]),
            "cached_decode_tokens_per_second": _summary([x[1] for x in runs]),
            "memory": memory,
            "notes": ["Prefill includes final-token logits; tokenization and model loading are excluded.",
                      "Cached decode measures fixed one-token forwards after prefill, with greedy selection.",
                      "Compilation and warmup are excluded. Launch each model in a fresh process.",
                      "CPU tensor memory is reported in model.parameter_bytes; total CPU RSS is not measured."]}


@torch.inference_mode()
def generate_text(model, tokenizer, *, prompt: str, max_new_tokens: int = 128,
                  chat: bool = False, thinking: bool = False, temperature: float = 0.0) -> str:
    if max_new_tokens < 1 or temperature < 0:
        raise ValueError("Invalid generation settings")
    if chat:
        if not getattr(tokenizer, "chat_template", None):
            raise ValueError("This tokenizer has no chat template; use a chat Qwen3 or omit --chat")
        prompt = tokenizer.apply_chat_template([{"role": "user", "content": prompt}], tokenize=False,
                                               add_generation_prompt=True, enable_thinking=thinking)
    inputs = tokenizer(prompt, return_tensors="pt", add_special_tokens=False)
    device = next(model.parameters()).device
    inputs = {k: v.to(device) for k, v in inputs.items()}
    length = inputs["input_ids"].shape[1]
    if length == 0 or length + max_new_tokens > model.config.max_position_embeddings:
        raise ValueError("Empty prompt or requested generation exceeds context limit")
    kwargs = {"max_new_tokens": max_new_tokens, "do_sample": temperature > 0,
              "use_cache": True, "pad_token_id": (tokenizer.pad_token_id if tokenizer.pad_token_id is not None
                                                     else tokenizer.eos_token_id)}
    if temperature > 0:
        kwargs.update(temperature=temperature, top_p=0.9)
    output = model.generate(**inputs, **kwargs)
    return tokenizer.decode(output[0, length:], skip_special_tokens=True)


def compare_reports(baseline_path: str, result_paths: list[str], benchmark_paths: list[str],
                    output: str, max_ppl_ratio: float = 1.05) -> dict:
    if max_ppl_ratio < 1:
        raise ValueError("max_ppl_ratio must be at least 1")
    baseline = read_json(baseline_path)
    if baseline.get("report_type") != "language_model_evaluation" or baseline["perplexity"] is None:
        raise ValueError("Baseline must be a finite perplexity evaluation report")
    bench = {}
    for path in benchmark_paths:
        report = read_json(path)
        if report.get("report_type") != "benchmark":
            raise ValueError(f"Not a benchmark report: {path}")
        key = report["model"]["model_id"]
        if key in bench:
            raise ValueError("Duplicate benchmark reports for one model; select one protocol")
        bench[key] = report
    base_id = baseline["model"]["model_id"]
    base_bench = bench.get(base_id)
    rows = []
    seen = {}
    for report in [baseline, *(read_json(p) for p in result_paths)]:
        if report.get("report_type") != "language_model_evaluation":
            raise ValueError("All result inputs must be language-model evaluation reports")
        key = report["model"]["model_id"]
        if key in seen:
            if report != seen[key]:
                raise ValueError("Duplicate, non-identical evaluation reports for one model; choose a single run")
            continue
        seen[key] = report
        if report["protocol"] != baseline["protocol"]:
            raise ValueError("Incomparable evaluation protocols/token streams. Re-evaluate with identical settings/data.")
        if report["model"]["base"]["fingerprint"] != baseline["model"]["base"]["fingerprint"]:
            raise ValueError("Compared models do not share base weights/tokenizer")
        if report["model"]["dtype"] != baseline["model"]["dtype"]:
            raise ValueError("Compare evaluation reports at the same dtype")
        ppl = report["perplexity"]
        ratio = ppl / baseline["perplexity"] if ppl is not None else None
        row = {"model": report["model"]["path"], "model_id": key,
               "parameters": report["model"]["parameters"],
               "parameter_ratio": report["model"]["parameters"] / baseline["model"]["parameters"],
               "parameter_bytes": report["model"]["parameter_bytes"], "perplexity": ppl,
               "perplexity_ratio": ratio, "quality_gate_passed": ratio is not None and ratio <= max_ppl_ratio,
               "prefill_ms": None, "decode_tokens_s": None, "decode_speedup": None}
        b = bench.get(key)
        if b:
            if base_bench:
                if b["protocol"] != base_bench["protocol"] or b["environment"] != base_bench["environment"]:
                    raise ValueError("Benchmark environment/protocol mismatch; speedup would be misleading")
            row["prefill_ms"] = b["prefill_ms"]["median"]
            row["decode_tokens_s"] = b["cached_decode_tokens_per_second"]["median"]
            if base_bench:
                row["decode_speedup"] = row["decode_tokens_s"] / base_bench["cached_decode_tokens_per_second"]["median"]
        rows.append(row)
    result = {"report_type": "comparison", "max_perplexity_ratio": max_ppl_ratio, "rows": rows,
              "note": "A local-MSE or perplexity gate is not a guarantee of task/chat quality."}
    out = Path(output)
    write_json(out.with_suffix(".json"), result)
    with out.with_suffix(".csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    lines = ["# Сравнение моделей", "", "| Модель | Параметры | PPL | PPL / baseline | Порог качества | Decode tok/s |",
             "|---|---:|---:|---:|---|---:|"]
    for row in rows:
        fmt = lambda value: "—" if value is None else f"{value:.4g}"
        name = row["model"].replace("|", "\\|")
        lines.append(f"| {name} | {row['parameters']:,} | {fmt(row['perplexity'])} | "
                     f"{fmt(row['perplexity_ratio'])} | {'PASS' if row['quality_gate_passed'] else 'FAIL'} | "
                     f"{fmt(row['decode_tokens_s'])} |")
    lines += ["", "Порог perplexity не заменяет проверку целевых задач и качества диалога.", ""]
    out.with_suffix(".md").write_text("\n".join(lines), encoding="utf-8")
    return result
