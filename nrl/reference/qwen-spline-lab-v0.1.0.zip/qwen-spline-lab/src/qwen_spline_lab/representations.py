from __future__ import annotations

from dataclasses import asdict, dataclass

import torch
from torch import nn
from torch.nn import functional as F

REPRESENTATIONS = ("dense", "pruned", "spline-linear", "spline-cubic", "svd")


@dataclass(frozen=True)
class BlockSpec:
    representation: str
    hidden_size: int
    original_width: int
    width: int = 0
    rank: int = 0
    knots: int = 16

    def __post_init__(self):
        if any(not isinstance(v, int) or isinstance(v, bool) for v in
               [self.hidden_size, self.original_width, self.width, self.rank, self.knots]):
            raise ValueError("All dimensions, rank and knot count must be integers")
        if self.representation not in REPRESENTATIONS:
            raise ValueError(f"Unknown representation: {self.representation}")
        if min(self.hidden_size, self.original_width) < 1:
            raise ValueError("Dimensions must be positive")
        if self.representation == "dense" and self.width != self.original_width:
            raise ValueError("Dense baseline must retain original width")
        if self.representation != "svd" and not 1 <= self.width <= self.original_width:
            raise ValueError("width must be in [1, original_width]")
        if self.representation == "svd" and not 1 <= self.rank <= min(self.hidden_size, self.original_width):
            raise ValueError("SVD rank is out of range")
        if self.knots < 2:
            raise ValueError("At least two spline knots are required")

    def to_dict(self) -> dict:
        return asdict(self)


class ChannelSpline(nn.Module):
    """Per-channel uniform-grid interpolation; linear tails, not clipping.

    'cubic' uses cubic Hermite segments with finite-difference slopes
    (Catmull-Rom interior slopes), NOT cubic B-splines. Interpolation is
    evaluated in FP32 for half/bfloat16 inputs to avoid inaccurate bin indices.
    """
    def __init__(self, channels: int, knots: int = 16, kind: str = "linear"):
        super().__init__()
        if channels < 1 or knots < 2 or kind not in {"linear", "cubic"}:
            raise ValueError("Invalid spline dimensions or kind")
        self.channels, self.knots, self.kind = channels, knots, kind
        self.register_buffer("low", torch.full((channels,), -6.0))
        self.register_buffer("high", torch.full((channels,), 6.0))
        self.values = nn.Parameter(torch.empty(channels, knots))
        self.initialize_silu()

    @torch.no_grad()
    def initialize_silu(self, activations: torch.Tensor | None = None) -> None:
        if activations is not None:
            a = activations.detach().float().reshape(-1, self.channels)
            low = torch.minimum(torch.quantile(a, 0.001, dim=0), a.new_full((self.channels,), -0.1))
            high = torch.maximum(torch.quantile(a, 0.999, dim=0), a.new_full((self.channels,), 0.1))
            self.low.copy_(low)
            self.high.copy_(high)
        t = torch.linspace(0, 1, self.knots, device=self.values.device, dtype=self.values.dtype)
        grid = self.low[:, None] + (self.high - self.low)[:, None] * t
        self.values.copy_(F.silu(grid))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if x.shape[-1] != self.channels:
            raise ValueError("Input channel count does not match spline")
        dtype = torch.float64 if x.dtype == torch.float64 else torch.float32
        a = x.to(dtype).reshape(-1, self.channels)
        low, high = self.low.to(dtype), self.high.to(dtype)
        u = (a - low) / (high - low) * (self.knots - 1)
        index = u.floor().long().clamp(0, self.knots - 2)
        channels = torch.arange(self.channels, device=x.device).view(1, -1)
        values = self.values.to(dtype)
        y0, y1 = values[channels, index], values[channels, index + 1]
        t = u - index.to(dtype)
        linear = y0 + (y1 - y0) * t
        if self.kind == "linear":
            result = linear
        else:
            before = values[channels, (index - 1).clamp(min=0)]
            after = values[channels, (index + 2).clamp(max=self.knots - 1)]
            m0 = torch.where(index == 0, y1 - y0, (y1 - before) * 0.5)
            m1 = torch.where(index == self.knots - 2, y1 - y0, (after - y0) * 0.5)
            tc = t.clamp(0, 1)  # avoid cubic growth even in unused extrapolation branch
            tc2, tc3 = tc * tc, tc * tc * tc
            cubic = ((2 * tc3 - 3 * tc2 + 1) * y0 + (tc3 - 2 * tc2 + tc) * m0
                     + (-2 * tc3 + 3 * tc2) * y1 + (tc3 - tc2) * m1)
            result = torch.where((u < 0) | (u > self.knots - 1), linear, cubic)
        return result.reshape(x.shape).to(x.dtype)

    def roughness(self) -> torch.Tensor:
        if self.knots < 3:
            return self.values.sum() * 0
        return (self.values[:, 2:] - 2 * self.values[:, 1:-1] + self.values[:, :-2]).square().mean()


class CompactGatedMLP(nn.Module):
    def __init__(self, spec: BlockSpec):
        super().__init__()
        self.spec = spec
        self.gate_proj = nn.Linear(spec.hidden_size, spec.width, bias=False)
        self.up_proj = nn.Linear(spec.hidden_size, spec.width, bias=False)
        self.down_proj = nn.Linear(spec.width, spec.hidden_size, bias=False)
        self.activation = (ChannelSpline(spec.width, spec.knots, spec.representation.split("-")[1])
                           if spec.representation.startswith("spline-") else nn.SiLU())

    def features(self, x: torch.Tensor) -> torch.Tensor:
        return self.activation(self.gate_proj(x)) * self.up_proj(x)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.down_proj(self.features(x))


class LowRankLinear(nn.Module):
    def __init__(self, inputs: int, outputs: int, rank: int):
        super().__init__()
        self.right = nn.Linear(inputs, rank, bias=False)
        self.left = nn.Linear(rank, outputs, bias=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.left(self.right(x))

    @torch.no_grad()
    def initialize(self, weight: torch.Tensor, method: str = "randomized") -> None:
        w = weight.detach().float()
        rank = self.right.out_features
        if method == "exact":
            u, s, vh = torch.linalg.svd(w, full_matrices=False)
        elif method == "randomized":
            u, s, v = torch.svd_lowrank(w, q=min(rank + 8, min(w.shape)), niter=2)
            vh = v.T
        else:
            raise ValueError(f"Unknown SVD method: {method}")
        root = s[:rank].sqrt()
        self.left.weight.copy_(u[:, :rank] * root)
        self.right.weight.copy_(root[:, None] * vh[:rank])


class SVDGatedMLP(nn.Module):
    def __init__(self, spec: BlockSpec):
        super().__init__()
        self.spec = spec
        self.gate_proj = LowRankLinear(spec.hidden_size, spec.original_width, spec.rank)
        self.up_proj = LowRankLinear(spec.hidden_size, spec.original_width, spec.rank)
        self.down_proj = LowRankLinear(spec.original_width, spec.hidden_size, spec.rank)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.down_proj(F.silu(self.gate_proj(x)) * self.up_proj(x))


def build_block(spec: BlockSpec) -> nn.Module:
    return SVDGatedMLP(spec) if spec.representation == "svd" else CompactGatedMLP(spec)


@torch.no_grad()
def select_channels(teacher: nn.Module, width: int, x: torch.Tensor | None) -> torch.Tensor:
    g, u, d = teacher.gate_proj.weight.float(), teacher.up_proj.weight.float(), teacher.down_proj.weight.float()
    if x is None:
        score = g.square().sum(1) * u.square().sum(1) * d.square().sum(0)
    else:
        total = torch.zeros(g.shape[0], device=g.device)
        count = 0
        for batch in x[:4096].split(256):
            batch = batch.to(device=g.device, dtype=g.dtype)
            feature = F.silu(F.linear(batch, g)) * F.linear(batch, u)
            total += feature.square().sum(0)
            count += batch.shape[0]
        score = total / max(count, 1) * d.square().sum(0)
    # Stable ordering makes the SiLU and spline controls share exactly the same channels.
    return score.argsort(descending=True, stable=True)[:width].sort().values


@torch.no_grad()
def initialize_block(teacher: nn.Module, spec: BlockSpec, x: torch.Tensor | None = None,
                     svd_method: str = "randomized") -> nn.Module:
    for name in ["gate_proj", "up_proj", "down_proj"]:
        layer = getattr(teacher, name)
        if not isinstance(layer, nn.Linear) or layer.bias is not None:
            raise ValueError("Conversion expects an unmodified, bias-free gated MLP")
    student = build_block(spec).to(device=teacher.gate_proj.weight.device, dtype=torch.float32)
    if spec.representation == "svd":
        for name in ["gate_proj", "up_proj", "down_proj"]:
            getattr(student, name).initialize(getattr(teacher, name).weight, svd_method)
        return student
    indices = (torch.arange(spec.original_width, device=teacher.gate_proj.weight.device)
               if spec.representation == "dense" else select_channels(teacher, spec.width, x))
    student.gate_proj.weight.copy_(teacher.gate_proj.weight[indices])
    student.up_proj.weight.copy_(teacher.up_proj.weight[indices])
    student.down_proj.weight.copy_(teacher.down_proj.weight[:, indices])
    if isinstance(student.activation, ChannelSpline):
        samples = None if x is None else student.gate_proj(x[:4096].to(student.gate_proj.weight))
        student.activation.initialize_silu(samples)
    return student


@torch.no_grad()
def refit_down(student: CompactGatedMLP, x: torch.Tensor, y: torch.Tensor, ridge: float = 1e-4) -> None:
    """Ridge regression on TRAIN data only. Accumulate Gram matrix in CPU float64."""
    if ridge <= 0:
        raise ValueError("ridge must be positive")
    p = student.down_proj.weight
    width, hidden = student.spec.width, student.spec.hidden_size
    gram = torch.zeros(width, width, dtype=torch.float64)
    rhs = torch.zeros(width, hidden, dtype=torch.float64)
    for start in range(0, len(x), 256):
        features = student.features(x[start:start + 256].to(p)).double().cpu()
        targets = y[start:start + 256].double().cpu()
        gram += features.T @ features
        rhs += features.T @ targets
    regularizer = ridge * (gram.trace() / width).clamp_min(1e-12)
    gram.diagonal().add_(regularizer)
    result = torch.linalg.solve(gram, rhs)
    p.copy_(result.T.to(p))
