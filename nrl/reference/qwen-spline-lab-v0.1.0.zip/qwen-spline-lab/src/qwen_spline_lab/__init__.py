"""Experimental compact Qwen3 MLP representations."""
__version__ = "0.1.0"
