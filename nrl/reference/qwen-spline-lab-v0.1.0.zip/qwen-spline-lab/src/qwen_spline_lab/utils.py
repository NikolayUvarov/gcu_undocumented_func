from __future__ import annotations

import contextlib
import hashlib
import importlib.metadata
import json
import os
import platform
import random
import shutil
import tempfile
from pathlib import Path
from typing import Any, Iterator

import numpy as np
import torch


def read_json(path: str | Path) -> dict:
    with Path(path).open(encoding="utf-8") as f:
        return json.load(f)


def write_json(path: str | Path, value: Any) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    # Reject NaN/Infinity: downstream comparisons should not silently accept them.
    text = json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def sha256_file(path: str | Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(4 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def digest(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def model_fingerprint(path: str | Path) -> str:
    """Hash actual weights/config/tokenizer, not a model's mutable repository name."""
    path = Path(path)
    if not path.is_dir():
        raise ValueError(f"Local model directory not found: {path}. Run qsl-download first.")
    names = {"config.json", "tokenizer.json", "tokenizer_config.json", "vocab.json", "merges.txt",
             "special_tokens_map.json", "added_tokens.json", "tokenizer.model", "generation_config.json"}
    files = sorted(p for p in path.iterdir() if p.is_file() and
                   (p.suffix in {".safetensors", ".jinja"} or p.name in names))
    if not any(p.suffix == ".safetensors" for p in files):
        raise ValueError(f"No safetensors weights in {path}")
    return digest([(p.name, p.stat().st_size, sha256_file(p)) for p in files])


@contextlib.contextmanager
def new_directory(path: str | Path) -> Iterator[Path]:
    """Commit a new artifact atomically. Never remove or overwrite the user's directory."""
    path = Path(path)
    if path.exists():
        raise FileExistsError(f"Output already exists: {path}. Choose a new directory.")
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = Path(tempfile.mkdtemp(prefix=f".{path.name}.partial-", dir=path.parent))
    try:
        yield tmp
        if path.exists():
            raise FileExistsError(path)
        os.replace(tmp, path)
    finally:
        if tmp.exists():
            shutil.rmtree(tmp)


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def choose_device(value: str) -> torch.device:
    if value == "auto":
        value = "cuda" if torch.cuda.is_available() else "cpu"
    device = torch.device(value)
    if device.type not in {"cpu", "cuda"}:
        raise ValueError("v0.1 supports CPU and CUDA only, not MPS/other devices.")
    if device.type == "cuda" and not torch.cuda.is_available():
        raise ValueError("CUDA requested but unavailable. Install the correct PyTorch build or use --device cpu.")
    return device


def choose_dtype(value: str, device: torch.device) -> torch.dtype:
    if value == "auto":
        return (torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16) \
            if device.type == "cuda" else torch.float32
    allowed = {"float32": torch.float32, "float16": torch.float16, "bfloat16": torch.bfloat16}
    if value not in allowed:
        raise ValueError(f"Unsupported dtype: {value}")
    if value == "float16" and device.type == "cpu":
        raise ValueError("Use float32 or bfloat16 on CPU; CPU float16 is intentionally disabled.")
    if value == "bfloat16" and device.type == "cuda" and not torch.cuda.is_bf16_supported():
        raise ValueError("This CUDA device does not support bfloat16; use float16.")
    return allowed[value]


def sync(device: torch.device) -> None:
    if device.type == "cuda":
        torch.cuda.synchronize(device)


def environment() -> dict:
    versions = {}
    for name in ["torch", "numpy", "safetensors", "transformers", "huggingface-hub", "accelerate"]:
        try:
            versions[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            versions[name] = None
    return {"python": platform.python_version(), "platform": platform.platform(), "packages": versions,
            "cuda_available": torch.cuda.is_available(), "cuda_version": torch.version.cuda,
            "torch_threads": torch.get_num_threads(), "cpu_logical_count": os.cpu_count(),
            "cpu_processor": platform.processor(),
            "cuda_devices": [torch.cuda.get_device_name(i) for i in range(torch.cuda.device_count())],
            "gpu": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None}


def parameter_stats(module: torch.nn.Module) -> dict:
    # Module.parameters() deduplicates tied embedding/lm_head parameters.
    params = list(module.parameters())
    buffers = list(module.buffers())
    return {"parameters": sum(p.numel() for p in params),
            "parameter_bytes": sum(p.numel() * p.element_size() for p in params),
            "buffer_bytes": sum(p.numel() * p.element_size() for p in buffers)}


def parse_layers(text: str, count: int) -> list[int]:
    if text == "all":
        return list(range(count))
    result = sorted({int(x.strip()) for x in text.split(",") if x.strip()})
    if not result or any(x < 0 or x >= count for x in result):
        raise ValueError(f"Layers must be in [0, {count - 1}], e.g. 3,14,24 or all")
    return result
