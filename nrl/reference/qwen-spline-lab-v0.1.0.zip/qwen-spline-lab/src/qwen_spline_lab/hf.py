"""Optional Hugging Face adapter. Core math/tests/demo do not import Transformers."""
from __future__ import annotations

import logging
from pathlib import Path

import torch
from safetensors.torch import load_model, save_model

from .artifacts import OVERLAY_FORMAT, STANDALONE_FORMAT, load_overlay
from .data import check_disjoint, corpus_digest, read_documents, save_pairs
from .representations import BlockSpec, build_block
from .utils import (digest, environment, model_fingerprint, new_directory, parameter_stats,
                    read_json, sha256_file, write_json)

log = logging.getLogger(__name__)


def require_hf():
    try:
        from transformers import AutoConfig, AutoModelForCausalLM, AutoTokenizer
    except ImportError as e:
        raise RuntimeError('Install the Hugging Face adapter first: pip install -e ".[hf]"') from e
    return AutoConfig, AutoModelForCausalLM, AutoTokenizer


def validate_qwen(config) -> None:
    if config.model_type != "qwen3" or getattr(config, "hidden_act", None) != "silu":
        raise ValueError("v0.1 supports dense text Qwen3 with SiLU only; not Qwen3-MoE/Next/3.5/GGUF")
    architectures = getattr(config, "architectures", None)
    if architectures and "Qwen3ForCausalLM" not in architectures:
        raise ValueError("Expected Qwen3ForCausalLM, not an embedding/reranking/classification model")
    if getattr(config, "quantization_config", None):
        raise ValueError("Use original floating-point weights, not a pre-quantized checkpoint")


def apply_blocks(model, blocks: dict) -> None:
    for index, block in blocks.items():
        if not 0 <= index < len(model.model.layers):
            raise ValueError(f"Invalid layer index {index}")
        if block.spec.hidden_size != model.config.hidden_size:
            raise ValueError("Patch hidden size does not match model")
        if block.spec.original_width != model.config.intermediate_size:
            raise ValueError("Patch original width does not match model")
        parameter = next(model.model.layers[index].mlp.parameters())
        model.model.layers[index].mlp = block.to(device=parameter.device, dtype=parameter.dtype)


def load_any(path: str | Path, device: torch.device, dtype: torch.dtype,
             base_override: str | None = None, attention: str = "sdpa"):
    AutoConfig, AutoModelForCausalLM, AutoTokenizer = require_hf()
    path = Path(path).resolve()
    if not path.is_dir():
        raise ValueError(f"Model directory not found: {path}. Download it using qsl-download.")
    manifest = read_json(path / "manifest.json") if (path / "manifest.json").exists() else None
    source = path
    if manifest and manifest.get("format") == OVERLAY_FORMAT:
        source = Path(base_override or manifest["base"]["source"]).resolve()
        if model_fingerprint(source) != manifest["base"]["fingerprint"]:
            raise ValueError("Base weights/tokenizer checksum differs from the artifact's base")
    config = AutoConfig.from_pretrained(str(source), local_files_only=True, trust_remote_code=False)
    validate_qwen(config)
    if manifest and manifest.get("format") == STANDALONE_FORMAT:
        weights = path / "compact.safetensors"
        if sha256_file(weights) != manifest["weights_sha256"]:
            raise ValueError("Standalone artifact checksum mismatch")
        # torch_dtype remains supported in the pinned 4.57.6 API.
        model = AutoModelForCausalLM.from_config(config, torch_dtype=dtype, attn_implementation=attention)
        blocks = {int(k): build_block(BlockSpec(**spec)) for k, spec in manifest["blocks"].items()}
        apply_blocks(model, blocks)
        model.tie_weights()
        load_model(model, str(weights), strict=True, device="cpu")
        try:
            from transformers import GenerationConfig
            model.generation_config = GenerationConfig.from_pretrained(str(path), local_files_only=True)
        except OSError:
            pass
        base = manifest["base"]
    else:
        if manifest and manifest.get("format") != OVERLAY_FORMAT:
            raise ValueError("Unknown model manifest format")
        model = AutoModelForCausalLM.from_pretrained(
            str(source), config=config, torch_dtype=dtype, attn_implementation=attention,
            local_files_only=True, trust_remote_code=False, use_safetensors=True,
            low_cpu_mem_usage=True)
        base = (manifest["base"] if manifest else
                {"source": str(source), "fingerprint": model_fingerprint(source),
                 "model_type": config.model_type, "parameters": parameter_stats(model)["parameters"]})
        if manifest:
            blocks, _ = load_overlay(path)
            apply_blocks(model, blocks)
    tokenizer = AutoTokenizer.from_pretrained(str(source), local_files_only=True, trust_remote_code=False)
    model.to(device).eval()
    model.requires_grad_(False)
    info = {"path": str(path), "model_id": manifest["artifact_id"] if manifest else base["fingerprint"],
            "base": base, "format": manifest["format"] if manifest else "huggingface-original",
            "dtype": str(dtype).removeprefix("torch."), "device": str(device),
            "attention": attention, **parameter_stats(model)}
    return model, tokenizer, info


def download_model(repo: str, output: str, revision: str = "main") -> dict:
    try:
        from huggingface_hub import HfApi, snapshot_download
    except ImportError as e:
        raise RuntimeError('Install dependencies: pip install -e ".[hf]"') from e
    target = Path(output)
    target.mkdir(parents=True, exist_ok=True)
    request = target / "download_request.json"
    expected = {"repository": repo, "requested_revision": revision}
    if request.exists() and read_json(request) != expected:
        raise ValueError("Output is assigned to a different repository/revision; use another directory")
    if not request.exists() and any(target.iterdir()):
        raise ValueError("Download output is not empty and has no matching download_request.json")
    write_json(request, expected)
    lock = target / "download_lock.json"
    if lock.exists():
        commit = read_json(lock)["commit"]
    else:
        commit = HfApi().model_info(repo_id=repo, revision=revision).sha
        write_json(lock, {**expected, "commit": commit})
    snapshot_download(repo_id=repo, revision=commit, local_dir=str(target),
                      allow_patterns=["*.json", "*.safetensors", "*.txt", "*.model", "*.jinja",
                                      "LICENSE*", "NOTICE*", "README.md"],
                      ignore_patterns=["*.bin", "*.pt", "*.pth", "*.py", "*.gguf"])
    config = read_json(target / "config.json")
    if config.get("model_type") != "qwen3":
        raise ValueError("Downloaded model is not dense Qwen3; use Qwen/Qwen3-0.6B-Base")
    result = {**expected, "commit": commit, "fingerprint": model_fingerprint(target)}
    write_json(target / "download.json", result)
    return result


@torch.inference_mode()
def capture_pairs(model, tokenizer, documents: list[str], layers: list[int],
                  max_tokens: int, context_length: int) -> tuple[dict, dict]:
    if max_tokens < 1 or context_length < 2:
        raise ValueError("Token budget must be positive and context length >= 2")
    buffers = {i: {"x": [], "y": [], "count": 0} for i in layers}
    handles = []
    for index in layers:
        def hook(module, inputs, output, index=index):
            buffer = buffers[index]
            remaining = max_tokens - buffer["count"]
            if remaining <= 0:
                return
            x = inputs[0].detach().reshape(-1, model.config.hidden_size)[:remaining]
            y = output.detach().reshape(-1, model.config.hidden_size)[:remaining]
            buffer["x"].append(x.cpu().clone())
            buffer["y"].append(y.cpu().clone())
            buffer["count"] += len(x)
        handles.append(model.model.layers[index].mlp.register_forward_hook(hook))
    used_documents = 0
    device = next(model.parameters()).device
    try:
        for text in documents:
            ids = tokenizer(text, add_special_tokens=False)["input_ids"]
            if not ids:
                continue
            used_documents += 1
            for start in range(0, len(ids), context_length):
                piece = ids[start:start + context_length]
                input_ids = torch.tensor([piece], dtype=torch.long, device=device)
                # Backbone only: do not allocate a tokens x 152k vocabulary logits tensor.
                model.model(input_ids=input_ids, use_cache=False, return_dict=True)
                if all(v["count"] >= max_tokens for v in buffers.values()):
                    break
            if all(v["count"] >= max_tokens for v in buffers.values()):
                break
    finally:
        for handle in handles:
            handle.remove()
    if any(v["count"] == 0 for v in buffers.values()):
        raise ValueError("No activation pairs were collected")
    pairs = {i: (torch.cat(v["x"]), torch.cat(v["y"])) for i, v in buffers.items()}
    return pairs, {"used_documents": used_documents,
                   "tokens_per_layer": {str(i): v["count"] for i, v in buffers.items()}}


def calibrate(model, tokenizer, info: dict, *, files: dict[str, str], output: str,
              layers: list[int], token_limits: dict[str, int], context_length: int,
              storage_dtype: torch.dtype = torch.float16) -> dict:
    if info["format"] != "huggingface-original":
        raise ValueError("v0.1 calibration teacher must be the original model, not a modified artifact")
    documents = {split: read_documents(path) for split, path in files.items()}
    hashes = check_disjoint(documents)
    result = {"format": "qsl-calibration-v1", "base": info["base"], "layers": layers,
              "context_length": context_length, "source_dtype": info["dtype"],
              "storage_dtype": str(storage_dtype), "document_hashes": hashes,
              "corpus_digests": {k: corpus_digest(v) for k, v in documents.items()},
              "environment": environment(), "splits": {}, "files": {}}
    with new_directory(output) as tmp:
        for split, docs in documents.items():
            log.info("Collecting %s: up to %d tokens per layer", split, token_limits[split])
            pairs, counts = capture_pairs(model, tokenizer, docs, layers, token_limits[split], context_length)
            result["splits"][split] = counts
            for index, (x, y) in pairs.items():
                name = f"layer_{index:03d}.{split}.safetensors"
                save_pairs(tmp / name, x, y, storage_dtype)
                result["files"][name] = sha256_file(tmp / name)
                if len(x) < token_limits[split]:
                    log.warning("%s layer %d: only %d tokens available (requested %d)",
                                split, index, len(x), token_limits[split])
            del pairs
        write_json(tmp / "calibration.json", result)
    return result


def export_standalone(model, tokenizer, info: dict, manifest: dict, output: str) -> dict:
    if manifest.get("format") != OVERLAY_FORMAT:
        raise ValueError("Export expects an overlay model")
    model.cpu().eval()
    with new_directory(output) as tmp:
        model.config.save_pretrained(str(tmp))
        tokenizer.save_pretrained(str(tmp))
        model.generation_config.save_pretrained(str(tmp))
        weights = tmp / "compact.safetensors"
        save_model(model, str(weights), metadata={"format": "pt"})
        result = {"format": STANDALONE_FORMAT, "base": manifest["base"], "blocks": manifest["blocks"],
                  "weights_sha256": sha256_file(weights), "weight_file_bytes": weights.stat().st_size,
                  "dtype": info["dtype"], "environment": environment(),
                  "parent_artifact_id": manifest["artifact_id"], **parameter_stats(model)}
        result["artifact_id"] = digest({"weights": result["weights_sha256"], "blocks": result["blocks"]})
        write_json(tmp / "manifest.json", result)
        (tmp / "LOAD_WITH_QSL.txt").write_text(
            "This is a custom QSL artifact. Use qsl-generate/evaluate/benchmark.\n"
            "AutoModelForCausalLM.from_pretrained() alone cannot reconstruct custom MLP blocks.\n"
            "Model weights retain the upstream model's license; project code uses MIT.\n", encoding="utf-8")
        # Preserve upstream notices without pretending the code license replaces the model license.
        source = Path(info["base"]["source"])
        import shutil
        for file in source.iterdir():
            if file.is_file() and (file.name.startswith("LICENSE") or file.name.startswith("NOTICE")):
                shutil.copy2(file, tmp / file.name)
    return result
