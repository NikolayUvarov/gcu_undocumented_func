from __future__ import annotations

import logging
from pathlib import Path

import torch

from .artifacts import load_overlay, save_overlay, verify_calibration
from .data import load_pairs, save_pairs
from .representations import BlockSpec, initialize_block, refit_down
from .training import block_metrics, train_block
from .utils import (choose_device, choose_dtype, environment, new_directory, parameter_stats,
                    parse_layers, read_json, seed_everything, sha256_file, write_json)

log = logging.getLogger(__name__)


def convert_model(args) -> dict:
    from .hf import load_any
    device = choose_device(args.device)
    model, _, info = load_any(args.model, device, choose_dtype(args.dtype, device), attention=args.attention)
    if info["format"] != "huggingface-original":
        raise ValueError("Convert from original Hugging Face weights, not a previously converted artifact")
    overrides = read_json(args.plan)["layers"] if args.plan else None
    layers = (sorted(map(int, overrides)) if overrides else parse_layers(args.layers, len(model.model.layers)))
    if not layers or any(i < 0 or i >= len(model.model.layers) for i in layers):
        raise ValueError("Conversion plan contains invalid layers")
    calibration = read_json(Path(args.calibration) / "calibration.json") if args.calibration else None
    if calibration:
        verify_calibration({"base": info["base"]}, calibration, layers)
    blocks, report = {}, {}
    for index in layers:
        settings = {"representation": args.representation, "width": args.width,
                    "rank": args.rank, "knots": args.knots}
        if overrides:
            unknown = set(overrides[str(index)]) - set(settings)
            if unknown:
                raise ValueError(f"Unknown plan keys: {sorted(unknown)}")
            settings.update(overrides[str(index)])
        if settings["representation"] == "dense":
            settings["width"] = model.config.intermediate_size
        spec = BlockSpec(hidden_size=model.config.hidden_size,
                         original_width=model.config.intermediate_size, **settings)
        teacher = model.model.layers[index].mlp
        train = load_pairs(args.calibration, index, "train") if calibration else None
        block = initialize_block(teacher, spec, None if train is None else train[0], args.svd_method)
        old_count, new_count = parameter_stats(teacher)["parameters"], parameter_stats(block)["parameters"]
        if new_count >= old_count and spec.representation != "dense" and not args.allow_expansion:
            raise ValueError(f"Layer {index} does not compress ({new_count} >= {old_count}). "
                             "Reduce width/rank or explicitly pass --allow-expansion.")
        if args.refit and train is not None and spec.representation not in {"dense", "svd"}:
            refit_down(block, *train, ridge=args.ridge)
        metrics = None
        if calibration:
            metrics = block_metrics(block, *load_pairs(args.calibration, index, "validation"))
        log.info("layer %d %s: %d -> %d parameters", index, spec.representation, old_count, new_count)
        blocks[index] = block.cpu()
        report[str(index)] = {"representation": spec.representation, "original_parameters": old_count,
                              "replacement_parameters": new_count, "initial_validation": metrics}
    manifest = save_overlay(args.output, blocks, info["base"], details={"conversion": report,
                            "seed": args.seed, "svd_method": args.svd_method, "ridge_refit": args.refit,
                            "calibration": str(Path(args.calibration).resolve()) if calibration else None})
    estimated = info["parameters"] + sum(v["replacement_parameters"] - v["original_parameters"] for v in report.values())
    result = {"artifact": str(Path(args.output).resolve()), "artifact_id": manifest["artifact_id"],
              "original_parameters": info["parameters"], "converted_parameters": estimated,
              "parameter_ratio": estimated / info["parameters"],
              "patch_file_bytes": manifest["patch_file_bytes"],
              "storage_note": "Overlay requires the original base; patch size is NOT full model size.",
              "layers": report}
    write_json(Path(args.output) / "conversion.json", result)
    return result


def train_artifact(args) -> dict:
    device = choose_device(args.device)
    blocks, manifest = load_overlay(args.artifact)
    calibration = read_json(Path(args.calibration) / "calibration.json")
    verify_calibration(manifest, calibration, list(blocks))
    reports = {}
    for index, block in blocks.items():
        log.info("Training layer %d (%s)", index, block.spec.representation)
        block.to(device)
        reports[str(index)] = train_block(
            block, load_pairs(args.calibration, index, "train"),
            load_pairs(args.calibration, index, "validation"), steps=args.steps,
            batch_size=args.batch_size, lr=args.lr, eval_every=args.eval_every,
            seed=args.seed, smoothness=args.smoothness)
        block.cpu()
    result = {"parent_artifact_id": manifest["artifact_id"], "layers": reports,
              "environment": environment(), "test_split_used": False,
              "calibration": str(Path(args.calibration).resolve())}
    saved = save_overlay(args.output, blocks, manifest["base"], details={"training": result})
    result["artifact_id"] = saved["artifact_id"]
    write_json(Path(args.output) / "training.json", result)
    return result


def test_blocks(args) -> dict:
    device = choose_device(args.device)
    blocks, manifest = load_overlay(args.artifact)
    meta = read_json(Path(args.calibration) / "calibration.json")
    verify_calibration(manifest, meta, list(blocks))
    reports = {}
    for index, block in blocks.items():
        block.to(device)
        reports[str(index)] = {**block_metrics(block, *load_pairs(args.calibration, index, args.split)),
                              **parameter_stats(block), "representation": block.spec.representation}
    result = {"report_type": "block_test", "artifact_id": manifest["artifact_id"], "split": args.split,
              "environment": environment(), "layers": reports,
              "note": "Local block error is not full-model perplexity or task accuracy."}
    if args.output:
        write_json(args.output, result)
    return result


def synthetic_demo(output: str, steps: int = 80, seed: int = 42) -> dict:
    """End-to-end offline numerical demo. Deliberately NOT a language-model evaluation."""
    from .representations import CompactGatedMLP, REPRESENTATIONS
    seed_everything(seed)
    teacher = CompactGatedMLP(BlockSpec("dense", 24, 64, width=64)).eval()
    teacher.requires_grad_(False)
    pairs = {}
    with torch.no_grad():
        for split, count in [("train", 1024), ("validation", 256), ("test", 256)]:
            x = torch.randn(count, 24)
            pairs[split] = x, teacher(x)
    base = {"source": "synthetic://gated-mlp-24x64", "fingerprint": f"synthetic-seed-{seed}",
            "model_type": "synthetic-mlp", "parameters": parameter_stats(teacher)["parameters"]}
    with new_directory(output) as tmp:
        calibration = tmp / "calibration"
        calibration.mkdir()
        meta = {"format": "qsl-calibration-v1", "base": base, "layers": [0], "synthetic": True,
                "document_hashes": {}, "files": {}}
        for split, (x, y) in pairs.items():
            name = f"layer_000.{split}.safetensors"
            save_pairs(calibration / name, x, y, torch.float32)
            meta["files"][name] = sha256_file(calibration / name)
        write_json(calibration / "calibration.json", meta)
        results = []
        for representation in REPRESENTATIONS:
            seed_everything(seed)
            spec = BlockSpec(representation, 24, 64, width=64 if representation == "dense" else 24,
                             rank=6, knots=16)
            block = initialize_block(teacher, spec, pairs["train"][0], svd_method="exact")
            if representation not in {"dense", "svd"}:
                refit_down(block, *pairs["train"])
            initial = block_metrics(block, *pairs["validation"])
            history = None
            if representation != "dense":
                history = train_block(block, pairs["train"], pairs["validation"], steps=steps,
                                      batch_size=128, lr=1e-3, eval_every=max(steps // 4, 1), seed=seed)
            artifact = tmp / representation
            save_overlay(artifact, {0: block}, base, details={"synthetic_only": True})
            reloaded, _ = load_overlay(artifact)
            with torch.no_grad():
                error = (reloaded[0](pairs["test"][0]) - block(pairs["test"][0])).abs().max().item()
            results.append({"representation": representation, **parameter_stats(block),
                            "initial_validation": initial, "test": block_metrics(reloaded[0], *pairs["test"]),
                            "save_load_max_abs_error": error, "training": history})
        report = {"report_type": "synthetic_demo", "seed": seed, "steps": steps,
                  "teacher_parameters": base["parameters"], "environment": environment(), "results": results,
                  "warning": "Random synthetic MLP only. Not trained Qwen weights, not language quality, not speedup evidence."}
        write_json(tmp / "report.json", report)
    return report
