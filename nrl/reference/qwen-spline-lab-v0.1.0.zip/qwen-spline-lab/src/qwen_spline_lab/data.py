from __future__ import annotations

import hashlib
import json
import random
from pathlib import Path

import torch
from safetensors.torch import load_file, save_file

from .utils import digest, new_directory, read_json, sha256_file, write_json


def document_hash(text: str) -> str:
    # Exact duplicates and whitespace-only variations cannot cross split boundaries.
    return hashlib.sha256(" ".join(text.split()).encode("utf-8")).hexdigest()


def read_documents(path: str | Path) -> list[str]:
    path = Path(path)
    if path.suffix.lower() == ".jsonl":
        docs = []
        with path.open(encoding="utf-8") as f:
            for line_no, line in enumerate(f, 1):
                if not line.strip():
                    continue
                value = json.loads(line)
                if not isinstance(value, dict) or not isinstance(value.get("text"), str):
                    raise ValueError(f"{path}:{line_no}: expected a JSON object with a string 'text'")
                docs.append(value["text"])
    elif path.suffix.lower() == ".txt":
        docs = path.read_text(encoding="utf-8").replace("\r\n", "\n").split("\n\n")
    else:
        raise ValueError("Input corpus must be .jsonl or .txt (blank lines separate .txt documents)")
    docs = [d.strip() for d in docs if d.strip()]
    if not docs:
        raise ValueError(f"No documents in {path}")
    return docs


def check_disjoint(splits: dict[str, list[str]]) -> dict[str, list[str]]:
    seen: dict[str, str] = {}
    hashes = {}
    for split, docs in splits.items():
        hashes[split] = [document_hash(d) for d in docs]
        for h in hashes[split]:
            if h in seen and seen[h] != split:
                raise ValueError(f"Document leakage: identical text occurs in {seen[h]} and {split}")
            seen[h] = split
    return hashes


def split_corpus(source: str, output: str, seed: int = 42,
                 validation_fraction: float = 0.1, test_fraction: float = 0.1) -> dict:
    if not 0 < validation_fraction < 1 or not 0 < test_fraction < 1 or validation_fraction + test_fraction >= 1:
        raise ValueError("Validation/test fractions must be positive and sum to less than 1")
    original = read_documents(source)
    docs = list({document_hash(d): d for d in original}.values())
    if len(docs) < 3:
        raise ValueError("At least three unique documents are needed")
    random.Random(seed).shuffle(docs)
    nv, nt = max(1, int(len(docs) * validation_fraction)), max(1, int(len(docs) * test_fraction))
    if nv + nt >= len(docs):
        raise ValueError("Split leaves no training documents")
    splits = {"validation": docs[:nv], "test": docs[nv:nv + nt], "train": docs[nv + nt:]}
    with new_directory(output) as tmp:
        for name, items in splits.items():
            with (tmp / f"{name}.jsonl").open("w", encoding="utf-8") as f:
                for text in items:
                    f.write(json.dumps({"text": text}, ensure_ascii=False) + "\n")
        report = {"seed": seed, "source_sha256": sha256_file(source), "input_documents": len(original),
                  "unique_documents": len(docs), "split_documents": {k: len(v) for k, v in splits.items()},
                  "document_hashes": check_disjoint(splits)}
        write_json(tmp / "split.json", report)
    return report


def save_pairs(path: Path, x: torch.Tensor, y: torch.Tensor, dtype: torch.dtype = torch.float16) -> None:
    if x.ndim != 2 or x.shape != y.shape or len(x) == 0:
        raise ValueError("Calibration pairs must be equal non-empty [tokens, hidden] matrices")
    save_file({"x": x.detach().cpu().to(dtype).contiguous(), "y": y.detach().cpu().to(dtype).contiguous()},
              str(path), metadata={"format": "pt"})


def load_pairs(directory: str | Path, layer: int, split: str) -> tuple[torch.Tensor, torch.Tensor]:
    if split not in {"train", "validation", "test"}:
        raise ValueError("Unknown calibration split")
    root = Path(directory)
    name = f"layer_{layer:03d}.{split}.safetensors"
    meta = read_json(root / "calibration.json")
    if name not in meta["files"] or sha256_file(root / name) != meta["files"][name]:
        raise ValueError(f"Missing or corrupted calibration file: {name}")
    values = load_file(str(root / name))
    x, y = values["x"], values["y"]
    if x.ndim != 2 or x.shape != y.shape or len(x) == 0:
        raise ValueError("Invalid calibration pair shape")
    if not torch.isfinite(x).all() or not torch.isfinite(y).all():
        raise ValueError("Calibration contains NaN or Inf; regenerate with float32 storage")
    return x, y


def evaluation_windows(ids: list[int], context: int, stride: int, max_targets: int | None = None):
    """Yield (window ids, first scored predecessor index, number of scored targets).

    Every target 1..len(ids)-1 is scored exactly once. Windows never cross documents.
    At most `context` input tokens and at least one predecessor are included.
    """
    if context < 2 or not 1 <= stride < context:
        raise ValueError("Need context >= 2 and 1 <= stride < context")
    remaining = len(ids) - 1 if max_targets is None else min(max_targets, len(ids) - 1)
    target_start = 1
    while remaining > 0:
        n = min(stride, remaining)
        target_end = target_start + n
        begin = max(0, target_end - context)
        yield ids[begin:target_end], target_start - begin - 1, n
        remaining -= n
        target_start = target_end


def corpus_digest(docs: list[str]) -> str:
    # Order matters because evaluation can impose a token limit.
    return digest([document_hash(d) for d in docs])
