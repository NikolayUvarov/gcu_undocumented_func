from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path

import torch

from .utils import choose_device, choose_dtype, environment, parse_layers, read_json, seed_everything, write_json


def _common(parser):
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--threads", type=int, default=0, help="CPU torch threads; 0 leaves runtime default")


def _runtime(parser, model=True):
    if model:
        parser.add_argument("--model", required=True, help="Local original model, overlay, or standalone directory")
        parser.add_argument("--base", help="Relocated base model directory, for overlays")
    parser.add_argument("--device", default="auto", help="auto, cpu, cuda, cuda:0")
    parser.add_argument("--dtype", choices=["auto", "float32", "float16", "bfloat16"], default="auto")
    parser.add_argument("--attention", choices=["sdpa", "eager"], default="sdpa")


def parser_factory() -> argparse.ArgumentParser:
    from .representations import REPRESENTATIONS
    parser = argparse.ArgumentParser(prog="qsl", description="Qwen Spline Lab: experimental MLP representations")
    parser.add_argument("--debug", action="store_true", help="Show full tracebacks")
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("download", help="Download and pin an original Qwen3 snapshot")
    p.add_argument("--repo", default="Qwen/Qwen3-0.6B-Base")
    p.add_argument("--revision", default="main")
    p.add_argument("--output", required=True)

    p = sub.add_parser("split", help="Deduplicate and split local documents before calibration")
    p.add_argument("--input", required=True)
    p.add_argument("--output", required=True)
    p.add_argument("--validation-fraction", type=float, default=0.1)
    p.add_argument("--test-fraction", type=float, default=0.1)

    p = sub.add_parser("calibrate", help="Record MLP input/output pairs without vocabulary logits")
    _runtime(p)
    for name in ["train", "validation", "test"]:
        p.add_argument(f"--{name}", required=True, help="Local .jsonl or .txt documents")
    p.add_argument("--layers", default="14")
    p.add_argument("--train-tokens", type=int, default=8192)
    p.add_argument("--validation-tokens", type=int, default=2048)
    p.add_argument("--test-tokens", type=int, default=2048)
    p.add_argument("--context", type=int, default=256)
    p.add_argument("--storage-dtype", choices=["float16", "float32"], default="float16")
    p.add_argument("--output", required=True)

    p = sub.add_parser("convert", help="Initialize one of five representations, or a mixed layer plan")
    _runtime(p)
    p.add_argument("--representation", choices=REPRESENTATIONS, default="spline-linear")
    p.add_argument("--layers", default="14")
    p.add_argument("--width", type=int, default=1024)
    p.add_argument("--rank", type=int, default=256)
    p.add_argument("--knots", type=int, default=16)
    p.add_argument("--calibration")
    p.add_argument("--plan", help="JSON plan with per-layer representation overrides")
    p.add_argument("--svd-method", choices=["randomized", "exact"], default="randomized")
    p.add_argument("--no-refit", action="store_false", dest="refit", default=True)
    p.add_argument("--ridge", type=float, default=1e-4)
    p.add_argument("--allow-expansion", action="store_true")
    p.add_argument("--output", required=True)

    p = sub.add_parser("train", help="Distill replacement blocks; keep the best validation checkpoint")
    p.add_argument("--artifact", required=True)
    p.add_argument("--calibration", required=True)
    p.add_argument("--output", required=True)
    p.add_argument("--device", default="auto")
    p.add_argument("--steps", type=int, default=500)
    p.add_argument("--batch-size", type=int, default=256)
    p.add_argument("--lr", type=float, default=1e-3)
    p.add_argument("--eval-every", type=int, default=50)
    p.add_argument("--smoothness", type=float, default=0.0)

    p = sub.add_parser("block-test", help="Held-out local error of replacement blocks")
    p.add_argument("--artifact", required=True)
    p.add_argument("--calibration", required=True)
    p.add_argument("--split", choices=["validation", "test"], default="test")
    p.add_argument("--device", default="auto")
    p.add_argument("--output")

    p = sub.add_parser("evaluate", help="Full-model NLL/perplexity with correct target counting")
    _runtime(p)
    p.add_argument("--data", required=True)
    p.add_argument("--context", type=int, default=256)
    p.add_argument("--stride", type=int, default=128)
    p.add_argument("--max-tokens", type=int, default=4096)
    p.add_argument("--head-chunk", type=int, default=64)
    p.add_argument("--output", required=True)

    p = sub.add_parser("benchmark", help="Separate prefill and fixed-length cached-decode timings")
    _runtime(p)
    p.add_argument("--prompt", default="A small neural network can transform an input into an output.")
    p.add_argument("--context", type=int, default=128)
    p.add_argument("--decode-steps", type=int, default=32)
    p.add_argument("--repeats", type=int, default=5)
    p.add_argument("--warmup", type=int, default=2)
    p.add_argument("--compile-mlp", action="store_true")
    p.add_argument("--output", required=True)

    p = sub.add_parser("generate", help="Run a text completion or chat prompt")
    _runtime(p)
    p.add_argument("--prompt", required=True)
    p.add_argument("--max-new-tokens", type=int, default=128)
    p.add_argument("--chat", action="store_true")
    p.add_argument("--thinking", action="store_true")
    p.add_argument("--temperature", type=float, default=0.0)
    p.add_argument("--output", help="Optional JSON result")

    p = sub.add_parser("export", help="Create a self-contained custom model, without base-weight duplication")
    _runtime(p)
    p.add_argument("--output", required=True)

    p = sub.add_parser("compare", help="Validate report comparability; write JSON/CSV/Markdown")
    p.add_argument("--baseline", required=True)
    p.add_argument("--results", nargs="+", required=True)
    p.add_argument("--benchmarks", nargs="*", default=[])
    p.add_argument("--max-ppl-ratio", type=float, default=1.05)
    p.add_argument("--output", required=True, help="Output prefix, e.g. reports/comparison")

    p = sub.add_parser("doctor", help="Show environment and optional dependency availability")
    p.add_argument("--output")
    p = sub.add_parser("demo", help="Offline synthetic end-to-end test, no Hugging Face or model download")
    p.add_argument("--output", required=True)
    p.add_argument("--steps", type=int, default=80)
    for p in sub.choices.values():
        _common(p)
    return parser


def run(args):
    command = args.command
    if command == "doctor":
        result = environment()
        result["expected_transformers_version"] = "4.57.6"
        result["note"] = "Environment availability is not evidence of a successful real-Qwen conversion."
        if args.output:
            write_json(args.output, result)
        return result
    if command == "download":
        from .hf import download_model
        return download_model(args.repo, args.output, args.revision)
    if command == "split":
        from .data import split_corpus
        return split_corpus(args.input, args.output, args.seed, args.validation_fraction, args.test_fraction)
    if command == "demo":
        from .workflows import synthetic_demo
        if args.threads == 0:
            torch.set_num_threads(2)
        return synthetic_demo(args.output, args.steps, args.seed)
    if command == "convert":
        from .workflows import convert_model
        return convert_model(args)
    if command == "train":
        from .workflows import train_artifact
        return train_artifact(args)
    if command == "block-test":
        from .workflows import test_blocks
        return test_blocks(args)
    if command == "compare":
        from .evaluation import compare_reports
        return compare_reports(args.baseline, args.results, args.benchmarks, args.output, args.max_ppl_ratio)

    from .hf import load_any
    device = choose_device(args.device)
    dtype = choose_dtype(args.dtype, device)
    model, tokenizer, info = load_any(args.model, device, dtype, args.base, args.attention)
    if command == "calibrate":
        from .hf import calibrate
        if args.context > model.config.max_position_embeddings:
            raise ValueError("Context exceeds model configuration")
        files = {s: getattr(args, s) for s in ["train", "validation", "test"]}
        limits = {s: getattr(args, s + "_tokens") for s in files}
        return calibrate(model, tokenizer, info, files=files, output=args.output,
                         layers=parse_layers(args.layers, len(model.model.layers)), token_limits=limits,
                         context_length=args.context, storage_dtype=getattr(torch, args.storage_dtype))
    if command == "evaluate":
        from .evaluation import evaluate_language_model
        report = evaluate_language_model(model, tokenizer, info, args.data, context=args.context,
                                         stride=args.stride, max_tokens=args.max_tokens, head_chunk=args.head_chunk)
        write_json(args.output, report)
        return report
    if command == "benchmark":
        from .evaluation import benchmark_model
        report = benchmark_model(model, tokenizer, info, prompt=args.prompt, context=args.context,
                                 decode_steps=args.decode_steps, repeats=args.repeats, warmup=args.warmup,
                                 compile_mlp=args.compile_mlp)
        write_json(args.output, report)
        return report
    if command == "generate":
        from .evaluation import generate_text
        text = generate_text(model, tokenizer, prompt=args.prompt, max_new_tokens=args.max_new_tokens,
                             chat=args.chat, thinking=args.thinking, temperature=args.temperature)
        report = {"model": info, "prompt": args.prompt, "completion": text}
        if args.output:
            write_json(args.output, report)
        return report
    if command == "export":
        from .hf import export_standalone
        return export_standalone(model, tokenizer, info, read_json(Path(args.model) / "manifest.json"), args.output)
    raise ValueError(f"Unknown command {command}")


def main(argv=None):
    parser = parser_factory()
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s", stream=sys.stderr)
    try:
        if args.threads < 0:
            raise ValueError("--threads must be >= 0")
        if args.threads:
            torch.set_num_threads(args.threads)
        seed_everything(args.seed)
        result = run(args)
        print(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False))
    except KeyboardInterrupt:
        print("Interrupted. Existing artifacts have not been overwritten.", file=sys.stderr)
        raise SystemExit(130)
    except (ValueError, OSError, RuntimeError, KeyError) as e:
        if args.debug:
            raise
        parser.error(str(e))


def download_entry(): main(["download", *sys.argv[1:]])
def split_entry(): main(["split", *sys.argv[1:]])
def calibrate_entry(): main(["calibrate", *sys.argv[1:]])
def convert_entry(): main(["convert", *sys.argv[1:]])
def train_entry(): main(["train", *sys.argv[1:]])
def block_test_entry(): main(["block-test", *sys.argv[1:]])
def evaluate_entry(): main(["evaluate", *sys.argv[1:]])
def benchmark_entry(): main(["benchmark", *sys.argv[1:]])
def generate_entry(): main(["generate", *sys.argv[1:]])
def export_entry(): main(["export", *sys.argv[1:]])
def compare_entry(): main(["compare", *sys.argv[1:]])
def doctor_entry(): main(["doctor", *sys.argv[1:]])
def demo_entry(): main(["demo", *sys.argv[1:]])
