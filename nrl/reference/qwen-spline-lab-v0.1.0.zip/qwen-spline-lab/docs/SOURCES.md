# Первичные источники

Проверено при подготовке проекта 22 октября 2026 года. Реализация адаптера ориентирована на фиксированную версию Transformers 4.57.6; ссылки на main описывают API в целом, но не являются lock-файлом.

1. Qwen3 MLP и модель в Transformers **v4.57.6**:
   https://github.com/huggingface/transformers/blob/v4.57.6/src/transformers/models/qwen3/modeling_qwen3.py
2. Конфигурация исходной модели, размерности и tied embeddings:
   https://huggingface.co/Qwen/Qwen3-0.6B-Base/blob/main/config.json
3. Официальный механизм snapshot_download, local_dir и фиксация revision:
   https://huggingface.co/docs/huggingface_hub/en/guides/download
4. Safetensors, save_model/load_model и shared tensors:
   https://huggingface.co/docs/safetensors/en/api/torch
   https://huggingface.co/docs/safetensors/torch_shared_tensors
5. Liu et al., «KAN: Kolmogorov–Arnold Networks», 2024:
   https://arxiv.org/abs/2404.19756
6. PyTorch — точный и рандомизированный SVD:
   https://docs.pytorch.org/docs/2.10/generated/torch.linalg.svd.html
   https://docs.pytorch.org/docs/2.10/generated/torch.svd_lowrank.html
7. Hugging Face — оценка perplexity с ограниченным контекстом:
   https://huggingface.co/docs/transformers/perplexity
8. Официальные сведения об API загрузки моделей:
   https://huggingface.co/docs/transformers/v4.57.1/main_classes/model
9. Определение модели Qwen3 в документации:
   https://huggingface.co/docs/transformers/model_doc/qwen3

Данный проект не является официальным продуктом Qwen/Hugging Face/PyTorch и не заявляет воспроизведение результатов этих публикаций. Код конвертации, сплайнов, экспериментов и тестов написан для этого проекта; сторонние исходники и веса в архив не копировались.
